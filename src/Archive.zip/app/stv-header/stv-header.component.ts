import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stv-header',
  templateUrl: './stv-header.component.html',
  styleUrls: ['./stv-header.component.scss']
})
export class StvHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
